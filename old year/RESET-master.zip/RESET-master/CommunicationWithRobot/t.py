import typeConvertor

a = typeConvertor.TypeConvertor()
b = a.HexToFloat('b831adc9')

print b
