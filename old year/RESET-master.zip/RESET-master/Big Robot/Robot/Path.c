#include "Path.h"


//Path tracksPaths = 
//{
//  {0.0,0.0},//firstPath.center
//  
//  PI,//firstPath.alphZad
//  
//  2.0*PI,//firstPath.phihZad
//  
//  0.0,//firstPath.lengthTrace
//  
//  {2.0, 0.3, -2.0, 1.5, 2.0},//V_���, V_���, V_���, �_���, �_����
//  
//  //{0.0, 0.0, 0.0, 0.0, 0.0}
//  {0.7, 0.25, -1.0, 0.7, 0.7}
//};




void initPaths(void)
{
  
};

