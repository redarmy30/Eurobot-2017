#ifndef _EXTERN_VARIABLES_
#define _EXTERN_VARIABLES_

#include "stm32f4xx.h"
#include "Regulator.h"







#endif
